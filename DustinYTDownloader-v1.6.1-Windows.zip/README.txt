DustinYTDownloader 1.6.1
======================

Python 설치 없이 실행되는 간단한 Windows YouTube MP4/MP3 다운로더입니다.

사용법
1. 설치형은 DustinYTDownloader-Setup.exe를, 포터블형은 DustinYTDownloader-Portable.exe를 실행합니다.
2. YouTube URL을 붙여 넣습니다.
3. MP4 또는 MP3를 선택하고 다운로드를 누릅니다.
4. 결과는 기본적으로 Windows의 동영상\DustinYTDownloader 폴더에 저장됩니다.
5. 프로그램의 "저장 위치 변경" 버튼으로 원하는 폴더를 지정할 수 있습니다.

설치 위치
- DustinYTDownloader-Setup.exe에서 설치할 디렉터리를 직접 선택할 수 있습니다.
- 관리자 권한이 필요 없는 사용자 폴더가 기본값입니다.
- 설치형은 Windows 설정의 "설치된 앱"과 시작 메뉴에 DustinYTDownloader를 등록합니다.
- 포터블형은 Windows에 설치 정보를 등록하지 않습니다.
- 제거할 때 다운로드한 MP4/MP3와 사용자 설정은 유지됩니다.

첫 실행 안내
- 첫 다운로드 시 yt-dlp와 FFmpeg를 자동으로 준비합니다.
- 약 70~100MB 정도를 받을 수 있으며 인터넷 연결이 필요합니다.
- 준비된 엔진은 %LOCALAPPDATA%\DustinYTDownloader\tools 에 저장됩니다.
- YouTube 변경으로 다운로드가 실패하면 "전체 업데이트"를 누르세요.

앱 업데이트
- 앱을 켜면 공개 배포 저장소에서 새 버전을 자동으로 확인합니다.
- 새 버전이 있으면 내려받을지 먼저 묻고, 동의한 경우에만 설치 파일을 받습니다.
- 내려받은 설치 파일은 SHA-256 검증을 통과해야 실행됩니다.
- 설치형 사용자는 기존 설치 폴더가 자동 선택되어 같은 위치에 업데이트됩니다.
- 업데이트해도 다운로드한 MP4/MP3와 저장 위치 설정은 유지됩니다.

지원 범위
- 공개적으로 접근 가능한 일반 YouTube/youtu.be URL
- 단일 영상 MP4 다운로드 또는 MP3 변환
- MP4는 재생 호환성이 높은 H.264 영상과 AAC 오디오를 우선 사용합니다.
- 로그인, DRM, 유료 콘텐츠, 연령/지역 제한 우회 기능은 제공하지 않습니다.

주의
이 앱은 개인적·비상업적 백업 전용입니다.
본인이 소유했거나 저작권자·서비스로부터 명시적으로 다운로드와 백업 허가를 받은 콘텐츠에만 사용하세요.
상업적 사용, 재배포, 권리 없는 콘텐츠의 복제, 로그인·DRM·유료·연령·지역 제한 우회는 금지됩니다.
제작자는 저작권 침해나 약관 위반을 의도·승인·권장하지 않으며, 사용 가능 여부와 결과에 대한 책임은 사용자에게 있습니다.
소프트웨어는 관련 법률이 허용하는 범위에서 어떠한 보증이나 손해배상 책임 없이 제공됩니다.
설치 또는 사용 전에 함께 제공되는 LICENSE.txt 전문을 반드시 확인하세요.

라이선스
- Copyright (c) 2026 DustinJung. All Rights Reserved.
- 개인·비상업적 사용만 제한적으로 허용하는 독점 라이선스입니다.
- 소스·실행 파일의 복제, 수정, 재배포, 판매, 상업적 사용 및 파생 저작물 제작을 금지합니다.
- yt-dlp와 FFmpeg 등 제3자 구성요소는 각자의 원래 라이선스를 따릅니다.

사용 구성요소
- yt-dlp: https://github.com/yt-dlp/yt-dlp
- FFmpeg Windows builds: https://github.com/BtbN/FFmpeg-Builds
- FFmpeg: https://ffmpeg.org/
