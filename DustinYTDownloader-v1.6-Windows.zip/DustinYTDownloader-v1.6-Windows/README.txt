DustinYTDownloader 1.6
======================

Python 설치 없이 실행되는 간단한 Windows YouTube MP4/MP3 다운로더입니다.

사용법
1. 설치형은 DustinYTDownloader-Setup.exe를, 포터블형은 DustinYTDownloader-Portable.exe를 실행합니다.
2. YouTube URL을 붙여 넣습니다.
3. MP4 또는 MP3를 선택하고 다운로드를 누릅니다.
4. 결과는 기본적으로 Windows의 동영상\DustinYTDownloader 폴더에 저장됩니다.
5. 프로그램의 "저장 위치 변경" 버튼으로 원하는 폴더를 지정할 수 있습니다.

설치 위치
- DustinYTDownloader-Setup.exe에서 설치할 디렉터리를 직접 선택할 수 있습니다.
- 관리자 권한이 필요 없는 사용자 폴더가 기본값입니다.
- 설치형은 Windows 설정의 "설치된 앱"과 시작 메뉴에 DustinYTDownloader를 등록합니다.
- 포터블형은 Windows에 설치 정보를 등록하지 않습니다.
- 제거할 때 다운로드한 MP4/MP3와 사용자 설정은 유지됩니다.

첫 실행 안내
- 첫 다운로드 시 yt-dlp와 FFmpeg를 자동으로 준비합니다.
- 약 70~100MB 정도를 받을 수 있으며 인터넷 연결이 필요합니다.
- 준비된 엔진은 %LOCALAPPDATA%\DustinYTDownloader\tools 에 저장됩니다.
- YouTube 변경으로 다운로드가 실패하면 "전체 업데이트"를 누르세요.

앱 업데이트
- 앱을 켜면 공개 배포 저장소에서 새 버전을 자동으로 확인합니다.
- 새 버전이 있으면 내려받을지 먼저 묻고, 동의한 경우에만 설치 파일을 받습니다.
- 내려받은 설치 파일은 SHA-256 검증을 통과해야 실행됩니다.
- 설치형 사용자는 기존 설치 폴더가 자동 선택되어 같은 위치에 업데이트됩니다.
- 업데이트해도 다운로드한 MP4/MP3와 저장 위치 설정은 유지됩니다.

지원 범위
- 공개적으로 접근 가능한 일반 YouTube/youtu.be URL
- 단일 영상 MP4 다운로드 또는 MP3 변환
- MP4는 재생 호환성이 높은 H.264 영상과 AAC 오디오를 우선 사용합니다.
- 로그인, DRM, 유료 콘텐츠, 연령/지역 제한 우회 기능은 제공하지 않습니다.

주의
본인이 소유했거나 다운로드 허가를 받은 콘텐츠에만 사용하세요.
YouTube 및 콘텐츠 제공자의 이용약관과 저작권을 준수하세요.

사용 구성요소
- yt-dlp: https://github.com/yt-dlp/yt-dlp
- FFmpeg Windows builds: https://github.com/BtbN/FFmpeg-Builds
- FFmpeg: https://ffmpeg.org/
